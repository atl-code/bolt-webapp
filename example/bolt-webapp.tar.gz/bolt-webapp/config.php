<?php
$currency = 'USD';
$db_username = 'admin';
$db_password = 'superduper';
$db_name = 'bolt';
$db_host = 'prop1.crqunf6fanaw.us-east-1.rds.amazonaws.com';
$mysqli = new mysqli($db_host, $db_username, $db_password,$db_name);
?>
